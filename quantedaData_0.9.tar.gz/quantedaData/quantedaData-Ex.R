pkgname <- "quantedaData"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('quantedaData')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
cleanEx()
nameEx("exampleString")
### * exampleString

flush(stderr()); flush(stdout())

### Name: exampleString
### Title: A paragraph of text for testing various text-based functions
### Aliases: exampleString

### ** Examples

data(exampleString)
clean(exampleString)



cleanEx()
nameEx("iebudgets")
### * iebudgets

flush(stderr()); flush(stdout())

### Name: iebudgets
### Title: Irish budget speeches
### Aliases: ie2010Corpus ieDocvars, ieTexts, iebudgets

### ** Examples

# load the Irish budget speeches
data(iebudgets)
ie2010corp <- subset(iebudgets, year==2010)  # just the 2010 speeches
summary(ie2010corp)
summary(subset(iebudgets, no=="02"))  # just the Finance Minister (always first)
                                     # note that "no" is a factor, not integer

# create a corpus (just five speeches)
mycorpus <- corpus(ieTexts, docvars=ieDocvars)
summary(mycorpus)



### * <FOOTER>
###
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
